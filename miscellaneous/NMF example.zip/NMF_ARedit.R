setwd("~/Course to teach/Computing/NMFexample/NMFexample")
#The example is due to Dorothy Ellis
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("Biobase")

library(jpeg)
library(raster)
library(magick)
library(NMF)
rotate<-function(x) t(apply(x,2,rev))

hudsbw<-readJPEG("hudsonsmallerbw.jpg")
#function for rotating the figure

#hudsbwrray<-raster::as.array(hudsbw)
#Make sure that it is in black and white; it should be since it is saved that way,
#but this way of plotting only works for black and white images since it is
#compressing the pixels in the X and Y axis
hudsbwrray<-(hudsbw[,,1]+hudsbw[,,2]+hudsbw[,,3])/3

numfactors<-30
newnmf<-nmf(hudsbwrray,numfactors,seed="nndsvd")
Wmat <- newnmf@fit@W

Hmat<-newnmf@fit@H
WH30<-newnmf@fit@W%*%newnmf@fit@H

numfactors<-80
newnmf<-nmf(hudsbwrray,numfactors,seed="nndsvd")
Wmat <- newnmf@fit@W
Hmat<-newnmf@fit@H
WH80<-newnmf@fit@W%*%newnmf@fit@H

png("original.png", height = 8, width = 8, units = "in", res=600)
image(hudsbwrray,main="Original",col=grey(seq(0, 1, length = 256)))
dev.off()
png("rank30.png", height = 8, width = 8, units = "in", res=600)
image(WH30, main="Rank R=30",col=grey(seq(0, 1, length = 256)))
dev.off()
png("rank80.png", height = 8, width = 8, units = "in", res=600)
image(WH80, main="Rank R=80", col=grey(seq(0, 1, length = 256)))
dev.off()
